def saudar(nome):
    print(f"Olá, {nome}! Seja bem-vindo(a)!")
saudar ("joão")
