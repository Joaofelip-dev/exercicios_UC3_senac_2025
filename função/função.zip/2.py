contador = 1
while contador <=10:
    print(contador)
    contador+=1