nota = float(input("Insira a sua nota de (0 a 10):"))

if nota >=0 and nota <=10:
    print("Nota registrada")

