idade = int(input("Informe a sua idade:"))

if idade >18:
    print("Acesso liberado")
else:
    print("Acesso negado")