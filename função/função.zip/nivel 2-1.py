numero = int(input("Digite um numero:"))
soma = 0
while numero != 0:
    soma += numero
    numero = int(input("Digite um numero:"))
    
print(soma)
