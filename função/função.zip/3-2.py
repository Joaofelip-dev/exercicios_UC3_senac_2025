idade = int(input("Informe a sua idade:"))
def verificar_idade(idade):
    if idade>=18:
        print("maior de idade")
    else:
        print("menor de idade")

verificar_idade(idade)