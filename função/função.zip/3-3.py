def calcular_media(n1,n2):
    media = (n1+n2)/2
    if media>=7:
        print("Aprovado")
    else:
        print("Reprovado")

calcular_media(4,8)